<?xml version="1.0" encoding="UTF-8"?>
<Profile xmlns="http://soap.sforce.com/2006/04/metadata">
    <applicationVisibilities>
        <application>standard__AllTabSet</application>
        <default>false</default>
        <visible>true</visible>
    </applicationVisibilities>
    <applicationVisibilities>
        <application>standard__AppLauncher</application>
        <default>false</default>
        <visible>true</visible>
    </applicationVisibilities>
    <applicationVisibilities>
        <application>standard__Approvals</application>
        <default>false</default>
        <visible>true</visible>
    </applicationVisibilities>
    <applicationVisibilities>
        <application>standard__Chatter</application>
        <default>false</default>
        <visible>true</visible>
    </applicationVisibilities>
    <applicationVisibilities>
        <application>standard__Community</application>
        <default>false</default>
        <visible>true</visible>
    </applicationVisibilities>
    <applicationVisibilities>
        <application>standard__Content</application>
        <default>false</default>
        <visible>true</visible>
    </applicationVisibilities>
    <applicationVisibilities>
        <application>standard__DataGovernanceConsole</application>
        <default>false</default>
        <visible>true</visible>
    </applicationVisibilities>
    <applicationVisibilities>
        <application>standard__DataManager</application>
        <default>false</default>
        <visible>true</visible>
    </applicationVisibilities>
    <applicationVisibilities>
        <application>standard__FlowsApp</application>
        <default>false</default>
        <visible>true</visible>
    </applicationVisibilities>
    <applicationVisibilities>
        <application>standard__Insights</application>
        <default>false</default>
        <visible>true</visible>
    </applicationVisibilities>
    <applicationVisibilities>
        <application>standard__Integration</application>
        <default>false</default>
        <visible>true</visible>
    </applicationVisibilities>
    <applicationVisibilities>
        <application>standard__LightningBolt</application>
        <default>false</default>
        <visible>true</visible>
    </applicationVisibilities>
    <applicationVisibilities>
        <application>standard__LightningInstrumentation</application>
        <default>false</default>
        <visible>true</visible>
    </applicationVisibilities>
    <applicationVisibilities>
        <application>standard__LightningSales</application>
        <default>false</default>
        <visible>true</visible>
    </applicationVisibilities>
    <applicationVisibilities>
        <application>standard__LightningSalesConsole</application>
        <default>false</default>
        <visible>true</visible>
    </applicationVisibilities>
    <applicationVisibilities>
        <application>standard__LightningScheduler</application>
        <default>false</default>
        <visible>false</visible>
    </applicationVisibilities>
    <applicationVisibilities>
        <application>standard__LightningService</application>
        <default>false</default>
        <visible>true</visible>
    </applicationVisibilities>
    <applicationVisibilities>
        <application>standard__MSJApp</application>
        <default>false</default>
        <visible>true</visible>
    </applicationVisibilities>
    <applicationVisibilities>
        <application>standard__Marketing</application>
        <default>false</default>
        <visible>true</visible>
    </applicationVisibilities>
    <applicationVisibilities>
        <application>standard__Platform</application>
        <default>false</default>
        <visible>false</visible>
    </applicationVisibilities>
    <applicationVisibilities>
        <application>standard__QueueManagement</application>
        <default>false</default>
        <visible>true</visible>
    </applicationVisibilities>
    <applicationVisibilities>
        <application>standard__RevenueCloudConsole</application>
        <default>false</default>
        <visible>true</visible>
    </applicationVisibilities>
    <applicationVisibilities>
        <application>standard__Sales</application>
        <default>true</default>
        <visible>true</visible>
    </applicationVisibilities>
    <applicationVisibilities>
        <application>standard__SalesCloudMobile</application>
        <default>false</default>
        <visible>true</visible>
    </applicationVisibilities>
    <applicationVisibilities>
        <application>standard__SalesforceCMS</application>
        <default>false</default>
        <visible>true</visible>
    </applicationVisibilities>
    <applicationVisibilities>
        <application>standard__Service</application>
        <default>false</default>
        <visible>true</visible>
    </applicationVisibilities>
    <applicationVisibilities>
        <application>standard__ServiceConsole</application>
        <default>false</default>
        <visible>false</visible>
    </applicationVisibilities>
    <applicationVisibilities>
        <application>standard__Shield</application>
        <default>false</default>
        <visible>true</visible>
    </applicationVisibilities>
    <applicationVisibilities>
        <application>standard__Sites</application>
        <default>false</default>
        <visible>true</visible>
    </applicationVisibilities>
    <classAccesses>
        <apexClass>BankAcct</apexClass>
        <enabled>false</enabled>
    </classAccesses>
    <classAccesses>
        <apexClass>Chinnu1219</apexClass>
        <enabled>false</enabled>
    </classAccesses>
    <classAccesses>
        <apexClass>ContactsDuplicateController</apexClass>
        <enabled>false</enabled>
    </classAccesses>
    <classAccesses>
        <apexClass>ContactsDuplicatesController</apexClass>
        <enabled>false</enabled>
    </classAccesses>
    <classAccesses>
        <apexClass>CreateContactFromCan</apexClass>
        <enabled>false</enabled>
    </classAccesses>
    <classAccesses>
        <apexClass>DailyTestJob</apexClass>
        <enabled>false</enabled>
    </classAccesses>
    <classAccesses>
        <apexClass>DailyTestScheduler</apexClass>
        <enabled>false</enabled>
    </classAccesses>
    <classAccesses>
        <apexClass>LeadConvertionClass</apexClass>
        <enabled>false</enabled>
    </classAccesses>
    <classAccesses>
        <apexClass>ScheduleTestclassprep</apexClass>
        <enabled>false</enabled>
    </classAccesses>
    <classAccesses>
        <apexClass>SkRecordTypeSelectionController</apexClass>
        <enabled>false</enabled>
    </classAccesses>
    <custom>false</custom>
    <layoutAssignments>
        <layout>Account-Account Layout</layout>
    </layoutAssignments>
    <layoutAssignments>
        <layout>AlternativePaymentMethod-Alternative Payment Method Layout</layout>
    </layoutAssignments>
    <layoutAssignments>
        <layout>ApiAnomalyEventStore-API Anomaly Event Store Layout</layout>
    </layoutAssignments>
    <layoutAssignments>
        <layout>AppointmentInvitation-Appointment Invitation Layout</layout>
    </layoutAssignments>
    <layoutAssignments>
        <layout>Asset-Asset Layout</layout>
    </layoutAssignments>
    <layoutAssignments>
        <layout>AssetAction-Asset Action Layout</layout>
    </layoutAssignments>
    <layoutAssignments>
        <layout>AssetActionSource-Asset Action Source Layout</layout>
    </layoutAssignments>
    <layoutAssignments>
        <layout>AssetRelationship-Asset Relationship Layout</layout>
    </layoutAssignments>
    <layoutAssignments>
        <layout>AssetStatePeriod-Asset State Period Layout</layout>
    </layoutAssignments>
    <layoutAssignments>
        <layout>AssignedResource-Assigned Resource Layout</layout>
    </layoutAssignments>
    <layoutAssignments>
        <layout>AssociatedLocation-Associated Location Layout</layout>
    </layoutAssignments>
    <layoutAssignments>
        <layout>AsyncOperationLog-Async Operation Log Layout</layout>
    </layoutAssignments>
    <layoutAssignments>
        <layout>AuthorizationForm-Authorization Form Layout</layout>
    </layoutAssignments>
    <layoutAssignments>
        <layout>AuthorizationFormConsent-Authorization Form Consent Layout</layout>
    </layoutAssignments>
    <layoutAssignments>
        <layout>AuthorizationFormDataUse-Authorization Form Data Use Layout</layout>
    </layoutAssignments>
    <layoutAssignments>
        <layout>AuthorizationFormText-Authorization Form Text Layout</layout>
    </layoutAssignments>
    <layoutAssignments>
        <layout>BusinessBrand-Business Brand Layout</layout>
    </layoutAssignments>
    <layoutAssignments>
        <layout>Campaign-Campaign Layout</layout>
    </layoutAssignments>
    <layoutAssignments>
        <layout>CampaignMember-Campaign Member Page Layout</layout>
    </layoutAssignments>
    <layoutAssignments>
        <layout>Candidate__c-Candidate Layout</layout>
    </layoutAssignments>
    <layoutAssignments>
        <layout>CardPaymentMethod-Card Payment Method Layout</layout>
    </layoutAssignments>
    <layoutAssignments>
        <layout>CartCheckoutSession-Cart Checkout Session Layout</layout>
    </layoutAssignments>
    <layoutAssignments>
        <layout>CartDeliveryGroup-Cart Delivery Group Layout</layout>
    </layoutAssignments>
    <layoutAssignments>
        <layout>CartDeliveryGroupMethod-Cart Delivery Group Method Layout</layout>
    </layoutAssignments>
    <layoutAssignments>
        <layout>CartItem-Cart Item Layout</layout>
    </layoutAssignments>
    <layoutAssignments>
        <layout>CartTax-Cart Tax Layout</layout>
    </layoutAssignments>
    <layoutAssignments>
        <layout>CartValidationOutput-Cart Validation Output Layout</layout>
    </layoutAssignments>
    <layoutAssignments>
        <layout>Case-Case Layout</layout>
    </layoutAssignments>
    <layoutAssignments>
        <layout>CaseClose-Close Case Layout</layout>
    </layoutAssignments>
    <layoutAssignments>
        <layout>CaseMilestone-Case Milestone Layout</layout>
    </layoutAssignments>
    <layoutAssignments>
        <layout>CommunityMemberLayout-Community Member Layout</layout>
    </layoutAssignments>
    <layoutAssignments>
        <layout>ConsumptionRate-Consumption Rate Layout</layout>
    </layoutAssignments>
    <layoutAssignments>
        <layout>ConsumptionSchedule-Consumption Schedule Layout</layout>
    </layoutAssignments>
    <layoutAssignments>
        <layout>Contact-Contact Layout</layout>
    </layoutAssignments>
    <layoutAssignments>
        <layout>Contact-Contact Layout</layout>
        <recordType>Contact.IBG_Contact</recordType>
    </layoutAssignments>
    <layoutAssignments>
        <layout>Contact-Contact Layout</layout>
        <recordType>Contact.Individual_Contact</recordType>
    </layoutAssignments>
    <layoutAssignments>
        <layout>ContactPointAddress-Contact Point Address Layout</layout>
    </layoutAssignments>
    <layoutAssignments>
        <layout>ContactPointEmail-Contact Point Email Layout</layout>
    </layoutAssignments>
    <layoutAssignments>
        <layout>ContactPointPhone-Contact Point Phone Layout</layout>
    </layoutAssignments>
    <layoutAssignments>
        <layout>ContactPointTypeConsent-Contact Point Type Consent Layout</layout>
    </layoutAssignments>
    <layoutAssignments>
        <layout>ContentVersion-Content Version Layout</layout>
    </layoutAssignments>
    <layoutAssignments>
        <layout>Contract-Contract Layout</layout>
    </layoutAssignments>
    <layoutAssignments>
        <layout>ContractLineItem-Contract Line Item Layout</layout>
    </layoutAssignments>
    <layoutAssignments>
        <layout>CredentialStuffingEventStore-Credential Stuffing Event Store Layout</layout>
    </layoutAssignments>
    <layoutAssignments>
        <layout>CreditMemo-Credit Memo Layout</layout>
    </layoutAssignments>
    <layoutAssignments>
        <layout>CreditMemoInvApplication-Credit Memo Invoice Application Layout</layout>
    </layoutAssignments>
    <layoutAssignments>
        <layout>CreditMemoLine-Credit Memo Line Layout</layout>
    </layoutAssignments>
    <layoutAssignments>
        <layout>Customer-Customer Layout</layout>
    </layoutAssignments>
    <layoutAssignments>
        <layout>DandBCompany-D%26B Company Layout</layout>
    </layoutAssignments>
    <layoutAssignments>
        <layout>DataUseLegalBasis-Data Use Legal Basis Layout</layout>
    </layoutAssignments>
    <layoutAssignments>
        <layout>DataUsePurpose-Data Use Purpose Layout</layout>
    </layoutAssignments>
    <layoutAssignments>
        <layout>DigitalWallet-Digital Wallet Layout</layout>
    </layoutAssignments>
    <layoutAssignments>
        <layout>DuplicateRecordSet-Duplicate Record Set Layout</layout>
    </layoutAssignments>
    <layoutAssignments>
        <layout>EmailMessage-Email Message Layout</layout>
    </layoutAssignments>
    <layoutAssignments>
        <layout>EngagementChannelType-Engagement Channel Type Layout</layout>
    </layoutAssignments>
    <layoutAssignments>
        <layout>Entitlement-Entitlement Layout</layout>
    </layoutAssignments>
    <layoutAssignments>
        <layout>EntityMilestone-Object Milestone Layout</layout>
    </layoutAssignments>
    <layoutAssignments>
        <layout>Event-Event Layout</layout>
    </layoutAssignments>
    <layoutAssignments>
        <layout>FeedItem-Feed Item Layout</layout>
    </layoutAssignments>
    <layoutAssignments>
        <layout>FinanceBalanceSnapshot-Finance Balance Snapshot Layout</layout>
    </layoutAssignments>
    <layoutAssignments>
        <layout>FinanceTransaction-Finance Transaction Layout</layout>
    </layoutAssignments>
    <layoutAssignments>
        <layout>FulfillmentOrder-Fulfillment Order Layout</layout>
    </layoutAssignments>
    <layoutAssignments>
        <layout>FulfillmentOrderItemAdjustment-Fulfillment Order Item Adjustment Layout</layout>
    </layoutAssignments>
    <layoutAssignments>
        <layout>FulfillmentOrderItemTax-Fulfillment Order Item Tax Layout</layout>
    </layoutAssignments>
    <layoutAssignments>
        <layout>FulfillmentOrderLineItem-Fulfillment Order Product Layout</layout>
    </layoutAssignments>
    <layoutAssignments>
        <layout>Global-Global Layout</layout>
    </layoutAssignments>
    <layoutAssignments>
        <layout>Idea-Idea Layout</layout>
    </layoutAssignments>
    <layoutAssignments>
        <layout>Individual-Individual Layout</layout>
    </layoutAssignments>
    <layoutAssignments>
        <layout>Invoice-Invoice Layout</layout>
    </layoutAssignments>
    <layoutAssignments>
        <layout>InvoiceLine-Invoice Line Layout</layout>
    </layoutAssignments>
    <layoutAssignments>
        <layout>Lead-Lead Layout</layout>
    </layoutAssignments>
    <layoutAssignments>
        <layout>LegalEntity-Legal Entity Layout</layout>
    </layoutAssignments>
    <layoutAssignments>
        <layout>LiveChatTranscriptActive-Chat Transcript %28In Progress%29 Layout</layout>
    </layoutAssignments>
    <layoutAssignments>
        <layout>LiveChatTranscriptWaiting-Chat Transcript %28Waiting%29 Layout</layout>
    </layoutAssignments>
    <layoutAssignments>
        <layout>Location-Location Layout</layout>
    </layoutAssignments>
    <layoutAssignments>
        <layout>LocationGroup-Location Group Layout</layout>
    </layoutAssignments>
    <layoutAssignments>
        <layout>LocationGroupAssignment-Location Group Assignment Layout</layout>
    </layoutAssignments>
    <layoutAssignments>
        <layout>Macro-Macro Layout</layout>
    </layoutAssignments>
    <layoutAssignments>
        <layout>OperatingHours-Operating Hours Layout</layout>
    </layoutAssignments>
    <layoutAssignments>
        <layout>Opportunity-Opportunity Layout</layout>
    </layoutAssignments>
    <layoutAssignments>
        <layout>OpportunityLineItem-Opportunity Product Layout</layout>
    </layoutAssignments>
    <layoutAssignments>
        <layout>Order-Order Layout</layout>
    </layoutAssignments>
    <layoutAssignments>
        <layout>OrderItem-Order Product Layout</layout>
    </layoutAssignments>
    <layoutAssignments>
        <layout>Payment-Payment Layout</layout>
    </layoutAssignments>
    <layoutAssignments>
        <layout>PaymentAuthAdjustment-Payment Authorization Adjustment Layout</layout>
    </layoutAssignments>
    <layoutAssignments>
        <layout>PaymentAuthorization-Payment Authorization Layout</layout>
    </layoutAssignments>
    <layoutAssignments>
        <layout>PaymentGateway-Payment Gateway Layout</layout>
    </layoutAssignments>
    <layoutAssignments>
        <layout>PaymentGatewayLog-Payment Gateway Log Layout</layout>
    </layoutAssignments>
    <layoutAssignments>
        <layout>PaymentGroup-Payment Group Layout</layout>
    </layoutAssignments>
    <layoutAssignments>
        <layout>PaymentLineInvoice-Payment Line Invoice Layout</layout>
    </layoutAssignments>
    <layoutAssignments>
        <layout>Pricebook2-Price Book Layout</layout>
    </layoutAssignments>
    <layoutAssignments>
        <layout>PricebookEntry-Price Book Entry Layout</layout>
    </layoutAssignments>
    <layoutAssignments>
        <layout>ProcessException-Process Exception Layout</layout>
    </layoutAssignments>
    <layoutAssignments>
        <layout>Product2-Product Layout</layout>
    </layoutAssignments>
    <layoutAssignments>
        <layout>ProductConsumptionSchedule-Product Consumption Schedule Layout</layout>
    </layoutAssignments>
    <layoutAssignments>
        <layout>QuickText-Quick Text Layout</layout>
    </layoutAssignments>
    <layoutAssignments>
        <layout>Refund-Refund Layout</layout>
    </layoutAssignments>
    <layoutAssignments>
        <layout>RefundLinePayment-Refund Line Payment Layout</layout>
    </layoutAssignments>
    <layoutAssignments>
        <layout>ReportAnomalyEventStore-Report Anomaly Event Store Layout</layout>
    </layoutAssignments>
    <layoutAssignments>
        <layout>ResourceAbsence-Resource Absence Layout</layout>
    </layoutAssignments>
    <layoutAssignments>
        <layout>ResourcePreference-Resource Preference Layout</layout>
    </layoutAssignments>
    <layoutAssignments>
        <layout>ReturnOrder-Return Order Layout</layout>
    </layoutAssignments>
    <layoutAssignments>
        <layout>ReturnOrderItemAdjustment-Return Order Item Adjustment Layout</layout>
    </layoutAssignments>
    <layoutAssignments>
        <layout>ReturnOrderItemTax-Return Order Item Tax Layout</layout>
    </layoutAssignments>
    <layoutAssignments>
        <layout>ReturnOrderLineItem-Return Order Line Item Layout</layout>
    </layoutAssignments>
    <layoutAssignments>
        <layout>Scorecard-Scorecard Layout</layout>
    </layoutAssignments>
    <layoutAssignments>
        <layout>ScorecardAssociation-Scorecard Association Layout</layout>
    </layoutAssignments>
    <layoutAssignments>
        <layout>ScorecardMetric-Scorecard Metric Layout</layout>
    </layoutAssignments>
    <layoutAssignments>
        <layout>Seller-Seller Layout</layout>
    </layoutAssignments>
    <layoutAssignments>
        <layout>ServiceAppointment-Service Appointment Layout</layout>
    </layoutAssignments>
    <layoutAssignments>
        <layout>ServiceContract-Service Contract Layout</layout>
    </layoutAssignments>
    <layoutAssignments>
        <layout>ServiceResource-Service Resource Layout</layout>
    </layoutAssignments>
    <layoutAssignments>
        <layout>ServiceResourceSkill-Service Resource Skill Layout</layout>
    </layoutAssignments>
    <layoutAssignments>
        <layout>ServiceTerritory-Service Territory Layout</layout>
    </layoutAssignments>
    <layoutAssignments>
        <layout>ServiceTerritoryMember-Service Territory Member Layout</layout>
    </layoutAssignments>
    <layoutAssignments>
        <layout>SessionHijackingEventStore-Session Hijacking Event Store Layout</layout>
    </layoutAssignments>
    <layoutAssignments>
        <layout>Shift-Shift Layout</layout>
    </layoutAssignments>
    <layoutAssignments>
        <layout>ShiftWorkTopic-%5F%5FMISSING LABEL%5F%5F PropertyFile - val ShiftWorkTopic not found in section StandardLayouts</layout>
    </layoutAssignments>
    <layoutAssignments>
        <layout>SkillRequirement-Skill Requirement Layout</layout>
    </layoutAssignments>
    <layoutAssignments>
        <layout>SocialPersona-Social Persona Layout</layout>
    </layoutAssignments>
    <layoutAssignments>
        <layout>Solution-Solution Layout</layout>
    </layoutAssignments>
    <layoutAssignments>
        <layout>Task-Task Layout</layout>
    </layoutAssignments>
    <layoutAssignments>
        <layout>ThreatDetectionFeedback-Threat Detection Feedback Layout</layout>
    </layoutAssignments>
    <layoutAssignments>
        <layout>TimeSlot-Time Slot Layout</layout>
    </layoutAssignments>
    <layoutAssignments>
        <layout>User-User Layout</layout>
    </layoutAssignments>
    <layoutAssignments>
        <layout>UserAlt-User Profile Layout</layout>
    </layoutAssignments>
    <layoutAssignments>
        <layout>UserProvAccount-User Provisioning Account Layout</layout>
    </layoutAssignments>
    <layoutAssignments>
        <layout>UserProvisioningLog-User Provisioning Log Layout</layout>
    </layoutAssignments>
    <layoutAssignments>
        <layout>UserProvisioningRequest-User Provisioning Request Layout</layout>
    </layoutAssignments>
    <layoutAssignments>
        <layout>Waitlist-%5F%5FMISSING LABEL%5F%5F PropertyFile - val Waitlist not found in section StandardLayouts</layout>
    </layoutAssignments>
    <layoutAssignments>
        <layout>WebCart-Cart Layout</layout>
    </layoutAssignments>
    <layoutAssignments>
        <layout>WebCartAdjustmentBasis-Cart Adjustment Basis Layout</layout>
    </layoutAssignments>
    <layoutAssignments>
        <layout>WebCartAdjustmentGroup-Cart Adjustment Group Layout</layout>
    </layoutAssignments>
    <layoutAssignments>
        <layout>WebStore-Store Layout</layout>
    </layoutAssignments>
    <layoutAssignments>
        <layout>WebStoreConfig-Web Store Configuration Layout</layout>
    </layoutAssignments>
    <layoutAssignments>
        <layout>WorkOrder-Work Order Layout</layout>
    </layoutAssignments>
    <layoutAssignments>
        <layout>WorkOrderLineItem-Work Order Line Item Layout</layout>
    </layoutAssignments>
    <layoutAssignments>
        <layout>WorkPlan-Work Plan Layout</layout>
    </layoutAssignments>
    <layoutAssignments>
        <layout>WorkPlanTemplate-Work Plan Template Layout</layout>
    </layoutAssignments>
    <layoutAssignments>
        <layout>WorkPlanTemplateEntry-Work Plan Template Entry Layout</layout>
    </layoutAssignments>
    <layoutAssignments>
        <layout>WorkStep-Work Step Layout</layout>
    </layoutAssignments>
    <layoutAssignments>
        <layout>WorkStepTemplate-Work Step Template Layout</layout>
    </layoutAssignments>
    <layoutAssignments>
        <layout>WorkType-Work Type Layout</layout>
    </layoutAssignments>
    <layoutAssignments>
        <layout>WorkTypeGroup-Work Type Group Layout</layout>
    </layoutAssignments>
    <layoutAssignments>
        <layout>WorkTypeGroupMember-Work Type Group Member Layout</layout>
    </layoutAssignments>
    <recordTypeVisibilities>
        <default>false</default>
        <recordType>Contact.IBG_Contact</recordType>
        <visible>true</visible>
    </recordTypeVisibilities>
    <recordTypeVisibilities>
        <default>true</default>
        <recordType>Contact.Individual_Contact</recordType>
        <visible>true</visible>
    </recordTypeVisibilities>
    <tabVisibilities>
        <tab>Chinnu</tab>
        <visibility>DefaultOn</visibility>
    </tabVisibilities>
    <tabVisibilities>
        <tab>Chinnu1</tab>
        <visibility>DefaultOn</visibility>
    </tabVisibilities>
    <userLicense>Partner Community</userLicense>
    <userPermissions>
        <enabled>true</enabled>
        <name>ActivitiesAccess</name>
    </userPermissions>
    <userPermissions>
        <enabled>true</enabled>
        <name>AddDirectMessageMembers</name>
    </userPermissions>
    <userPermissions>
        <enabled>true</enabled>
        <name>AllowUniversalSearch</name>
    </userPermissions>
    <userPermissions>
        <enabled>true</enabled>
        <name>AssignTopics</name>
    </userPermissions>
    <userPermissions>
        <enabled>true</enabled>
        <name>ChatterOwnGroups</name>
    </userPermissions>
    <userPermissions>
        <enabled>true</enabled>
        <name>ContentWorkspaces</name>
    </userPermissions>
    <userPermissions>
        <enabled>true</enabled>
        <name>ConvertLeads</name>
    </userPermissions>
    <userPermissions>
        <enabled>true</enabled>
        <name>CreateTopics</name>
    </userPermissions>
    <userPermissions>
        <enabled>true</enabled>
        <name>EditOppLineItemUnitPrice</name>
    </userPermissions>
    <userPermissions>
        <enabled>true</enabled>
        <name>EditTask</name>
    </userPermissions>
    <userPermissions>
        <enabled>true</enabled>
        <name>EditTopics</name>
    </userPermissions>
    <userPermissions>
        <enabled>true</enabled>
        <name>EnableCommunityAppLauncher</name>
    </userPermissions>
    <userPermissions>
        <enabled>true</enabled>
        <name>EnableNotifications</name>
    </userPermissions>
    <userPermissions>
        <enabled>true</enabled>
        <name>RemoveDirectMessageMembers</name>
    </userPermissions>
    <userPermissions>
        <enabled>true</enabled>
        <name>RunFlow</name>
    </userPermissions>
    <userPermissions>
        <enabled>true</enabled>
        <name>RunReports</name>
    </userPermissions>
    <userPermissions>
        <enabled>true</enabled>
        <name>SelectFilesFromSalesforce</name>
    </userPermissions>
    <userPermissions>
        <enabled>true</enabled>
        <name>ShowCompanyNameAsUserBadge</name>
    </userPermissions>
    <userPermissions>
        <enabled>true</enabled>
        <name>UseWebLink</name>
    </userPermissions>
    <userPermissions>
        <enabled>true</enabled>
        <name>WorkDotComUserPerm</name>
    </userPermissions>
</Profile>
